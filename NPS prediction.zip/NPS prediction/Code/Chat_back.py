# coding=utf8
from Code.negative_words import negative_words,appreciated_words,\
    esclated_words,\
    derogatory_words
import html
import pandas as pd
import re
from nltk.tokenize import word_tokenize
from datetime import datetime,timedelta

def load_data():

    # file_name = "./Book1.xlsx"
    file_name = "./Book4.csv"
    # initial_data=pd.DataFrame()
    # d = pd.ExcelFile(file_name)
    # cut_head=1
    # sheets = ['SurveyChats', 'AccountChats']
    # for s in sheets:
    #     df_sheet=d.parse(file_name,sheet_name=s).iloc[cut_head:, :]
    #     pd.concat([initial_data, df_sheet], ignore_index=True)
    initial_data = pd.read_csv(file_name,encoding="iso-8859-1")
    initial_data['caseId'] = initial_data['caseId'].astype(str)
    initial_data.drop_duplicates(subset=['caseId'], keep="first",inplace=True)
    initial_data = initial_data[initial_data['caseId']!='nan']
    initial_data['accountNumber'] = initial_data['accountNumber'].astype(str)
    initial_data = initial_data[initial_data['accountNumber']!='nan']
    return initial_data


def get_features(data):
    # data.dropna (subset=['accountNumber','caseId'], inplace=True)
    # data.drop_duplicates(subset=['caseId'],inplace=True)
    data['accountNumber'] = data['accountNumber'].apply(lambda x: ('"' + str (x) + '"').strip ())
    d=datetime.strptime(str(max(data['chatStartDateTime'])),"%Y-%m-%d %H:%M:%S")
    t=timedelta(days=240)
    starts=d-t
    data=data[data['chatStartDateTime']>starts]
    data=data.dropna(subset=['contentTextInternal'])
    data['chat_length']=data['contentTextInternal'].apply(lambda x:len(x))
    data = data[data['chat_length']>1000]
    data['derogatory_words'] = data['contentTextInternal'].str.lower().apply(lambda x : len(set(re.sub(r'([^\s\w]|_)+', '', x).split()) & set(derogatory_words))).values
    data['negative_words'] = data['contentTextInternal'].str.lower().apply(lambda x : len(set(re.sub(r'([^\s\w]|_)+', '', x).split()) & set(negative_words))).values
    return data


def remove_html_tags(text):
    clean = re.compile('<.*?>')
    text=re.sub(clean,'',text)
    return text


def calculate_duration(start_time,end_time):
    start_time=start_time.replace('(','')
    start_time=start_time.replace(')','')
    timers=['am','pm']
    if all(word not in start_time for word in timers) and any(word in end_time for word in timers):
        datetime_object=datetime.strptime(start_time, '%H:%M %d %b %Y')
        start_time=datetime_object.strftime("%I:%M %p %d %b %Y")
        start_time=start_time.lower()
    if 'am' in start_time or 'pm' in start_time:
        datetime_object = datetime.strptime(start_time.strip(), '%I:%M %p %d %b %Y')
        if end_time[-2:].strip()=='am' and start_time.split()[1] =='pm':
            datetime_object=datetime_object+timedelta(days=1)
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %I:%M %p")- datetime_object
        return duration.seconds/60
    elif ('am' in start_time and 'am' in end_time) or ('pm' in start_time and 'pm' in end_time):
        datetime_object = datetime.strptime(start_time.strip(), '%I:%M %p %d %b %Y')
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %I:%M %p")- datetime_object
        return duration.seconds/60
    else:
        datetime_object = datetime.strptime(start_time.strip(), '%H:%M %d %b %Y')
        if start_time.split(":")[0] in ['22','23'] and end_time.split(":")[0] not in ['22','23']:
            datetime_object=datetime_object+timedelta(days=1)
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %H:%M")- datetime_object
        return duration.seconds/60


def preprocess_chat(chat):
    chat=chat.lower()
    chat = "".join([s for s in chat.splitlines(True) if s.strip("\r\n")])
    agent_chat=[]
    customer_chat=[]
    last_message=None
    if not isinstance(chat,float) and chat is not None:
        b=chat.splitlines()
        customer_name=next((x.split(":")[0][:-2] for x in b[:5] if "chat started at" not
                            in x and x and "system" not in x), "")
        customer_name = customer_name.strip()
        start_time=next((x.split(" at")[1][4:] for x in b[:2] if "chat started at" in x and x),"")
        start_time=start_time.strip()
        print("----------------------------------"+customer_name)
        for line in b:
            isAgent = False
            if "chat ended at" not in line and "chat started at" not in line \
                    and "has left the chat" not in line and "has ended the chat" \
                    not in line and not line.strip().startswith("system") and\
                    line is not None and line:
                line=line.strip()
                if "<" in line or ">" in line:
                    line=remove_html_tags(line)
                if ":" in line and line not in ["\n", "\r", "\t"]:
                    if line.split(":")[0][:-2].strip() == customer_name.strip():
                        isAgent=False
                        last_message = line.lower ().split (":")[:2]
                        last_message = last_message[0][-2:] + ":" + last_message[1]
                        print (customer_name + "----------------" + last_message)
                    else:
                        isAgent=True
                line = line.split(":")[2:]
                line = "".join(line)
                word_tokens = word_tokenize(line)
                line=" ".join(word_tokens)
                line=html.unescape(line)
                line=re.sub('[^A-Za-z\s]*','',line)
                line=line.replace(u'\xa0', u'')
                line=line.strip()
                if isAgent:
                    agent_chat.append(line)
                else:
                    customer_chat.append(line)
        print(start_time+"+++++++Time+++++++++++"+last_message)
        duration=calculate_duration(start_time,last_message)
        agent_chat=filter(None,agent_chat)
        customer_chat=filter(None,customer_chat)
        agent_appreciated=0
        if any(word in ",".join(list(customer_chat)[-5:]) for word in appreciated_words):
            agent_appreciated=1
        agent_chat = "\n".join(agent_chat)
        has_esclated=0
        if any(word in agent_chat for word in esclated_words):
            has_esclated = 1
        customer_chat = "\n".join(customer_chat)
        return duration,agent_appreciated,has_esclated


def get_processed_data():
    data = load_data()
    data = get_features(data)
    # new_columns = list(data.columns).append(['duration','appreciation',
    #                                       'esclation'])
    new_df = pd.DataFrame()
    for i,row in data.iterrows():
        my_frame = pd.DataFrame(row).transpose()
        d = a = h = 1
        try:
            d,a,h = preprocess_chat(row['contentTextInternal'])
        except:
            d=a=h=1
        my_frame['duration'] = d
        my_frame['appreciation'] = a
        my_frame['esclation'] = h
        new_df=pd.concat([new_df,my_frame],ignore_index=True)
    new_df.to_csv("Trainingabc.csv",index=False)
    # new_df.to_csv("Training 5k Chat 1.0.csv",index=False)


if __name__=="__main__":
    get_processed_data()
    # d = pd.read_excel("Testing/ChatTranscript_Consolidated.xlsx")
    # dv = pd.read_excel("Training/Book1.xlsx")
    # d = pd.concat([d,dv], ignore_index=True)
    # print(len(d))