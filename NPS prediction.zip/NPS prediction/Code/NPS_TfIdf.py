import pandas as pd
import nltk
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
import string
import re
from sklearn.utils import resample

lemma = nltk.WordNetLemmatizer()
# data1=pd.read_csv("Training 5k interactions 1.0.csv",encoding="iso-8859-1")
# data1=pd.read_csv("Training_interactions 1.0.csv",encoding="iso-8859-1")
# print(data1["NPS"].value_counts())

TEXT_CLASSIFIER = None
class Classify_query(object):
    def __init__(self,df):
        self.my_dataframe = df

        df_majority = self.my_dataframe[self.my_dataframe.NPS == 1]  # 1== promoters
        df_minority1 = self.my_dataframe[self.my_dataframe.NPS == 0]  # 0=Detractor
        df_minority2 = self.my_dataframe[self.my_dataframe.NPS == 2]  # 2=passives

        df_minority_upsampled1 = resample(df_minority1,
                                          replace=True,  # sample with replacement
                                          n_samples=2022,  # to match majority class
                                          random_state=123)

        df_minority_upsampled2 = resample(df_minority2,
                                          replace=True,  # sample with replacement
                                          n_samples=2022,  # to match majority class
                                          random_state=123)
        new_df = pd.concat([df_majority, df_minority_upsampled1,df_minority_upsampled2])
        self.feature_questions=new_df["contentTextInternal"]
        self.labels=new_df["NPS"]

    def ml_training (self):
        try:
            _feature_questions=[]
            _feature_questions_noun=[]
            _feature_questions_verb=[]
            feature_questions_punct=[]
            global TEXT_CLASSIFIER
            feature_lables=self.labels
            feature_questions_lwr = [x.lower() for x in self.feature_questions]
            for i in feature_questions_lwr:
                translation_table = dict.fromkeys(map(ord, string.punctuation),' ')
                string2 = i.translate(translation_table)  # translating string1
                feature_questions_punct.append(string2)
            feature_questions_spc = [s for s in feature_questions_punct if s]
            for i in feature_questions_spc:
                _feature_questions.append(re.sub('\s+', ' ', i).strip())
            print("lemma start")
            feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in _feature_questions]
            for i in feature_questions_noun:
                _feature_questions_noun.append(" ".join(i))
            feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in _feature_questions_noun]
            for i in feature_questions_verb:
                _feature_questions_verb.append(" ".join(i))
            print("lemma finish")
            interpretation_all_data=feature_lables
            print(_feature_questions_verb)
            X_train, X_test, y_train, y_test = train_test_split(_feature_questions_verb, interpretation_all_data, random_state=42)
            print("TFIDF vectorization start")
            tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2))
            text_classifier = Pipeline([
                ('vectorizer', tfidf_vectorizer),
                ('clf', SGDClassifier(loss='log',
                                      n_jobs=-1,
                                      max_iter=750,
                                      random_state=0,
                                      shuffle=True,
                                      tol=0.01))
            ])
            print("model training start -----------------")
            TEXT_CLASSIFIER = text_classifier.fit(X_train, y_train)
            global flag
            flag = True
        except Exception as exception:
            print(str(exception))

    def fetch_interpreted(self, question):
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.ml_training()
            print("faq _____fit again___")
        query = [question]
        query_label = []
        _feature_query=[]
        _feature_questions_noun_user = []
        _feature_questions_verb_user = []
        feature_pred_punct=[]
        feature_pred_lwr = [str(x).lower() for x in query]
        for i in feature_pred_lwr:
            translation_table = dict.fromkeys(map(ord, string.punctuation), ' ')
            string2 = i.translate(translation_table)  # translating string1
            feature_pred_punct.append(string2)
        feature_questions_spc = [s for s in feature_pred_punct if s]
        for i in feature_questions_spc:
            _feature_query.append(re.sub('\s+', ' ', i).strip())
        feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in _feature_query]
        for i in feature_questions_noun:
            _feature_questions_noun_user.append(" ".join(i))
        feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in _feature_questions_noun_user]
        for i in feature_questions_verb:
            query_label.append(" ".join(i))
        # print(query_label)
        pred = TEXT_CLASSIFIER.predict(query_label)

        otherpreds = TEXT_CLASSIFIER.predict_proba(query_label)[0]
        return otherpreds

#
if __name__ == "__main__":
    data1=pd.read_csv("Training 5k interactions 1.0.csv",encoding="iso-8859-1")
    data = pd.read_csv("Testing 5k interactions 1.0.csv",encoding="iso-8859-1")
    labels = {'Promoters': 1,'Detractors': 0,'Passives':2}
    data["NPS"] = [labels[item] for item in data["NPS"]]
    Detractor_prob=[]
    promoter_prob=[]
    passive_prob=[]
    obj=Classify_query(data1)
    for i, row in data.iterrows():
        p_category_prob = obj.fetch_interpreted(str(row['contentTextInternal']))
        Detractor_prob.append(p_category_prob[0])
        promoter_prob.append(p_category_prob[1])
        passive_prob.append(p_category_prob[2])
        print(p_category_prob,row['NPS'])
    df = pd.DataFrame({"det":Detractor_prob,
                       "pro_prob":promoter_prob,"pas_prob":passive_prob})
    new_df = pd.concat([data, df],axis=1)
    # new_df.to_csv("Final_1.15.csv", index=False)
    new_df.to_csv("medium.csv", index=False)

