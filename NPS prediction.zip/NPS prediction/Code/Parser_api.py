# -*- coding: utf-8 -*-
"""
Created on 16:01

@author: Rohit.Kumar18
"""

import spacy
nlp = spacy.load('en')
import re


def check_sentence(text):
    doc = nlp(text)
    my_tags=[]
    dependency=[]
    for token in doc:
        # print(token.text, token.tag_,token.i)
        my_tags.append(token.tag_)
        dependency.append(token.dep_)
    return my_tags,dependency


def get_tense():
    sentence = input(":")
    tokens,dependency = check_sentence(sentence)

    if "VBD" in tokens in tokens:
        check_grammer(sentence,tokens,dependency)


def check_grammer(sentence,tokens,root_tense):
    tokens_ok = check_tokens(sentence,tokens,root_tense)
    print(tokens_ok)


def check_rules(sentence,tokens,root_tense):
    comp_pairs=['JJR,IN','RB,JJR','JJR,NN,IN','JJS,NN','DT,NNP']
    adverb_pairs=['VBD,DT,NN,RB','VBD,RB',]
    adjective_pairs=['VBZ,DT,JJ']


def check_tokens(sentence,tokens,root_tense):
    simple_past_regex='''((JJ)*(NN)|(NNP)|(PRP)|(PRP\$NNS)*)*(RB)*(VBD)(RB)*(VB)*(
    TO)*(RB)*(VB)*(RB)*((JJ)*(NN)|(PRP))*(IN)*(DT)*(JJ)*(NN)*(.)*'''

    s_p_ques='''(RB)*(VBD)(RB)*(VB)*((JJ)*(NNP)|(PRP))*(TO)*(RB)*(VB)*(RB)*((
    JJ)*(NN)|(PRP))*(IN)*(PRP\$)*(DT)*(JJ)*(NN)*(.)*'''

    found_tokens="".join(tokens)
    simple_matches = re.match(re.compile(simple_past_regex),found_tokens)
    interro_matches=re.match(re.compile(s_p_ques),found_tokens)
    if simple_matches is None and interro_matches is None:
        return False
    elif simple_matches is None and interro_matches is not None:
        pass
    elif interro_matches is None and simple_matches is not None:
        pass
    else:
        return True
    s_p_q_rule=re.compile(s_p_ques)


get_tense()