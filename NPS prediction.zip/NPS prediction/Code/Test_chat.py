# coding=utf8
from Code.negative_words import negative_words,appreciated_words, \
    esclated_words, \
    derogatory_words
import html
import pandas as pd
import re
from nltk.tokenize import word_tokenize
from datetime import datetime,timedelta



def remove_html_tags(text):
    clean = re.compile('<.*?>')
    text=re.sub(clean,'',text)
    return text


def calculate_duration(start_time,end_time):
    start_time=start_time.replace('(','')
    start_time=start_time.replace(')','')
    timers=['am','pm']
    if all(word not in start_time for word in timers) and any(word in end_time for word in timers):
        datetime_object=datetime.strptime(start_time, '%H:%M %d %b %Y')
        start_time=datetime_object.strftime("%I:%M %p %d %b %Y")
        start_time=start_time.lower()
    if 'am' in start_time or 'pm' in start_time:
        datetime_object = datetime.strptime(start_time.strip(), '%I:%M %p %d %b %Y')
        if end_time[-2:].strip()=='am' and start_time.split()[1] =='pm':
            datetime_object=datetime_object+timedelta(days=1)
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %I:%M %p")- datetime_object
        return duration.seconds/60
    elif ('am' in start_time and 'am' in end_time) or ('pm' in start_time and 'pm' in end_time):
        datetime_object = datetime.strptime(start_time.strip(), '%I:%M %p %d %b %Y')
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %I:%M %p")- datetime_object
        return duration.seconds/60
    else:
        datetime_object = datetime.strptime(start_time.strip(), '%H:%M %d %b %Y')
        if start_time.split(":")[0] in ['22','23'] and end_time.split(":")[0] not in ['22','23']:
            datetime_object=datetime_object+timedelta(days=1)
        end_date=datetime_object.strftime("%Y-%m-%d")
        end_time=end_time.strip()
        end_date=end_date+" "+end_time
        duration=datetime.strptime(end_date,"%Y-%m-%d %H:%M")- datetime_object
        return duration.seconds/60


def preprocess_chat(chat):
    chat = chat.lower()
    chat = "".join([s for s in chat.splitlines(True) if s.strip("\r\n")])
    agent_chat=[]
    customer_chat=[]
    # agent_name=None
    last_message=None
    if not isinstance(chat,float) and chat is not None:
        b = chat.splitlines()
        # agent_name=next((x.split("with")[1].strip() for x in b if "chatting with" in x),"system")
        customer_name=next((x.split(":")[0][:-2] for x in b[:5] if "chat "
                                                                   "started "
                                                                   "at" not
                            in x and x and "system" not in x),"")
        start_time=next((x.split(" at")[1][4:] for x in b[:2] if "chat started at" in x and x),"")
        start_time=start_time.strip()
        print("----------------------------------"+customer_name)
        for line in b:
            isAgent = False
            if "chat ended at" not in line and "chat started at" not in line \
                    and "has left the chat" not in line and "has ended the chat" \
                    not in line and not line.strip().startswith("system") and \
                    line is not None and line:
                line=line.strip()
                if "<" in line or ">" in line:
                    line=remove_html_tags(line)
                if ":" in line and line not in ["\n", "\r", "\t"]:
                    # print(line.split(":")[0][:-2].strip()==customer_name.strip())
                    if line.split(":")[0][:-2].strip() == customer_name.strip():
                        isAgent=False
                        last_message = line.lower ().split (":")[:2]
                        last_message = last_message[0][-2:] + ":" + last_message[1]
                        print (customer_name + "----------------" + last_message)
                    else:
                        isAgent=True
                line = line.split(":")[2:]
                line = "".join(line)
                word_tokens = word_tokenize(line)
                line=" ".join(word_tokens)
                line=html.unescape(line)
                line=re.sub('[^A-Za-z\s]*','',line)
                line=line.replace(u'\xa0', u'')
                line=line.strip()
                if isAgent:
                    agent_chat.append(line)
                else:
                    customer_chat.append(line)
        print(start_time+"+++++++Time+++++++++++"+last_message)
        duration=calculate_duration(start_time,last_message)
        agent_chat=filter(None,agent_chat)
        customer_chat=filter(None,customer_chat)
        agent_appreciated=0
        if any(word in ",".join(list(customer_chat)[-5:]) for word in appreciated_words):
            agent_appreciated=1
        agent_chat = "\n".join(agent_chat)
        has_esclated=0
        if any(word in agent_chat for word in esclated_words):
            has_esclated = 1
        customer_chat = "\n".join(customer_chat)
        return duration,agent_appreciated,has_esclated


my_chat='''"<B>CHAT STARTED AT</B> 3:47 AM (3 Sep 2018)

AJAY GUPTA 3:47 AM : automatic billing &amp; late fee 
AJAY GUPTA 3:47 AM : hi 
system 3:47 AM : You are now chatting with Sandeep 
AJAY GUPTA 3:47 AM : I was on a uto bill 
AJAY GUPTA 3:47 AM : not sure w hat ha ppened 
Sandeep 3:48 AM : <p>Hi AJAY, thank you for contacting Xfinity Chat Support.Â  My name is Sandeep.Â Â I will be happy to assist you.</p>
 
AJAY GUPTA 3:48 AM : my    price went up and I was assessed late fee too 
AJAY GUPTA 3:48 AM : can  yu please look into it 
Sandeep 3:49 AM : I apologize for the inconvenience and thank you for the information,Ajay.let me check the best I can do for you from my end . 
Sandeep 3:49 AM : For account verification, may I please have your full name and complete service address along with the zip code? 
AJAY GUPTA 3:49 AM : ajay gupta 
AJAY GUPTA 3:49 AM : 145 whitestone ct 
AJAY GUPTA 3:49 AM : duluth, ga 30097 
Sandeep 3:50 AM : Thank you for this detail. 
Sandeep 3:51 AM : I am processing the credit of $10.00 for late fee on your account,please stay connected. 
AJAY GUPTA 3:52 AM : thanks 
AJAY GUPTA 3:52 AM : can you also please process a utomatic pa yments to my credit card and make m y monthly bill 19.99 that was there earier 
AJAY GUPTA 3:52 AM : last 2 bills were at a high er amount of 24.99 
Sandeep 3:53 AM : Let me check that for you. 
Sandeep 3:53 AM : Â  Â I am pleased to inform you that an adjustment of $10.00 is applied to your account. You should see the credit in the next billing cycle. 
Sandeep 3:53 AM : <table><tbody><tr><td height=""20"" width=""1669""><span style=""color:#000000""><a target=""_blank"" href=""https://customer.xfinity.com/#/recent-activity"" rel=""noopener noreferrer"">Â </a>You can check the credit applied online in next 24 to 48 hours at below link : <a target=""_blank"" href=""https://customer.xfinity.com/#/recent-activity"" rel=""noopener noreferrer"">https://customer.xfinity.com/#/recent-activity. </a></span></td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td><td width=""65"">Â </td></tr></tbody></table>
 
Sandeep 3:53 AM : Please stay connected ,while I ma working on the account. 
AJAY GUPTA 3:54 AM : thanks 
Sandeep 3:56 AM : To just confirm you want to set auto pay byÂ  <span style=""color:rgb( 54 , 54 , 54 )"">AmericanExpress ending in 1001</span> 
AJAY GUPTA 3:56 AM : yes, that was always teh card 
AJAY GUPTA 3:56 AM : on which I had autopay 
Sandeep 3:56 AM : Thank you. 
Sandeep 3:57 AM : <span style=""color:rgb( 54 , 54 , 54 )"">I have successfully enrolled you for auto payment.Payments will be deducted from theÂ </span><strong>AmericanExpress ending in 1001</strong><span style=""color:rgb( 54 , 54 , 54 )"">Â starting onÂ </span><strong>September 15, 2018</strong> 
Sandeep 3:57 AM : <table><tbody><tr><td>Email confirmation sent to:</td></tr><tr><td style=""text-align:left""><strong>contactajay&#64;gmail.com</strong></td></tr></tbody></table>
 
Sandeep 3:58 AM : We appreciate your business and value you as a customer. Please let me know if there is anything else I can help you with. 
AJAY GUPTA 3:59 AM : can you please process additional credit of $10\ 
AJAY GUPTA 3:59 AM : on account of higher billing last 2 cycles 
AJAY GUPTA 3:59 AM : I will make pa yment of remaining $59 right awa y online 
Sandeep 4:01 AM : Sure,please stay connected,Ajay. 
AJAY GUPTA 4:01 AM : Thanks, Sandeep 
Sandeep 4:02 AM : I have applied the credit of $10.00 for theÂ inconvenience caused to you. 
AJAY GUPTA 4:02 AM : Thanks! 
AJAY GUPTA 4:02 AM : appreciate it 
AJAY GUPTA 4:02 AM : i have meanwhile just paid 59.97 online so balance should be 0 
Sandeep 4:03 AM : Yes,that is correct.I hope I was able to help you in the best possible way here at my end, Â please share your opinion after ending theÂ  chat. 
AJAY GUPTA 4:03 AM : sure, thx 
Sandeep 4:03 AM : Thank you so much. 
Sandeep 4:03 AM : We appreciate your business and value you as a customer. Please let me know if there is anything else I can help you with. 
Sandeep 4:04 AM : To close the chat properly, please click &#39;END CHAT&#39; button located at the top right corner of the chat screen. 
Sandeep 4:04 AM : Thank you for choosing Xfinity and have a great night and take care always. 
AJAY GUPTA 4:04 AM : you too 
system 4:04 AM : AJAY GUPTA has left the chat 
system 4:06 AM : Sandeep has ended the chat 

<B>CHAT ENDED AT</B> 4:06 AM (3 Sep 2018)"
'''

print(preprocess_chat(my_chat))