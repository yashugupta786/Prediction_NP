__author__ = "Yashu Gupta"
import pandas as pd
import nltk
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
from sklearn.metrics import accuracy_score

lemma = nltk.WordNetLemmatizer()
from Code import tf_df, tst_chat

RF_TEXT_CLASSIFIER = None


class Nps_pred(object):
    def __init__(self):
        pass

    def ml_npstrain_model(self, my_dataframe, feature_names, max_key, max_value):
        try:
            global RF_TEXT_CLASSIFIER
            my_dataframe['DeadAirInstances'].fillna((my_dataframe['DeadAirInstances'].mean()), inplace=True)
            my_dataframe['DeadAirTotalMinutes'].fillna((my_dataframe['DeadAirTotalMinutes'].mean()), inplace=True)
            df_majority = my_dataframe[my_dataframe.NPS == 1]  # 1== promoters
            df_minority1 = my_dataframe[my_dataframe.NPS == 0]  # 0=Detractor
            df_minority2 = my_dataframe[my_dataframe.NPS == 2]  # 2=passives
            df_majority = resample(df_majority,
                                   replace=True,  # sample with replacement
                                   n_samples=int(max_value),  # to match majority class
                                   random_state=123)
            df_minority_upsampled1 = resample(df_minority1,
                                              replace=True,  # sample with replacement
                                              n_samples=int(max_value),  # to match majority class
                                              random_state=123)

            if not df_minority2.empty:
                df_minority_upsampled2 = resample(df_minority2,
                                                  replace=True,  # sample with replacement
                                                  n_samples=int(max_value),  # to match majority class
                                                  random_state=123)
                new_df = pd.concat([df_majority, df_minority_upsampled1, df_minority_upsampled2])
            else:
                new_df = pd.concat([df_majority, df_minority_upsampled1])
            # ----------------------------------------------------------------------------------
            # X = new_df[feature_names]

            if "passive_prob" not in new_df.columns:
                X = new_df[feature_names]
            else:
                f = feature_names + ["passive_prob"]
                X = new_df[f]

            y = new_df["NPS"]
            X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                                test_size=0.1,
                                                                random_state=42)
            text_classifier = RandomForestClassifier(n_jobs=-1, n_estimators=500, min_samples_leaf=1, max_depth=30,
                                                     random_state=137)
            RF_TEXT_CLASSIFIER = text_classifier.fit(X_train, y_train)
            print("RF model trained")
            pred = RF_TEXT_CLASSIFIER.predict(X_test)
            accuracy = accuracy_score(y_test, pred)
            F1score = f1_score(y_test, pred, average="macro")
            global flag
            flag = True
            return RF_TEXT_CLASSIFIER, accuracy, F1score
        except Exception as exception:
            print(str(exception))

    def get_predictions(self, query_points, rf_classifier):
        pred = rf_classifier.predict(query_points)
        otherpreds = rf_classifier.predict_proba(query_points)[0]
        otherq = []
        scores = []
        data = []
        i = 0
        limit = 3
        if (len(otherpreds) < 3):
            limit = len(otherpreds)
        while i < limit:
            max_score = np.argmax(otherpreds)
            otherq.append(max_score)
            scores.append(otherpreds[max_score])
            otherpreds[max_score] = -1
            i += 1
        data.append(pred)
        data.append(scores[0])
        return data

    def predict_NPS(self, Rf_textclasfier, test_data, feature_name):
        expected_NPS = []
        predicted_NPS = []
        predicted_conf = []
        caseIDs = []
        test_data['DeadAirInstances'].fillna((test_data['DeadAirInstances'].mean()), inplace=True)
        test_data['DeadAirTotalMinutes'].fillna((test_data['DeadAirTotalMinutes'].mean()), inplace=True)

        # if "passive_prob" not in test_data.columns:
        #     test_data = test_data[feature_name]
        # else:
        #     f = feature_name + ["passive_prob"]
        #     test_data = test_data[f]
        #
        if "passive_prob" in test_data.columns:
            feature_name=feature_name+["passive_prob"]
        #

        for i, row in test_data.iterrows():
            col_values = []
            for f in feature_name:
                col_values.append(str(row[f]))
            m_v = self.get_predictions([col_values], Rf_textclasfier)
            predictedresult = m_v[0]
            confidence = m_v[1]
            predicted_NPS.append(predictedresult[0])
            predicted_conf.append(confidence)
            caseIDs.append(row['caseId'])
            expected_NPS.append(row['NPS'])
        df = pd.DataFrame({"CaseId": caseIDs, "Expected": expected_NPS,
                           "Predicted": predicted_NPS, "confidence": predicted_conf})
        return df

#
# if __name__ == "__main__":
#     import numpy as np
#     obj = Nps_pred(training_data)
#     obj.ml_train_model()
#     test_data = pd.read_csv("Finaltesting_5kchats.csv",encoding="iso-8859-1")
#     expected_NPS = []
#     predicted_NPS = []
#     predicted_conf = []
#     caseIDs = []
#     for i, row in test_data.iterrows():
#         col_values = []
#         for f in feature_names:
#             col_values.append(str(row[f]))
#         m_v= obj.get_predictions([col_values])
#         predictedresult=m_v[0]
#         confidence=m_v[1]
#         predicted_NPS.append(predictedresult)
#         predicted_conf.append(confidence)
#         caseIDs.append(row['caseId'])
#         expected_NPS.append(row['NPS'])
#         # row['predictedNPS'] = m_v
#         # print(m_v,row['NPS'])
#     # test_data.to_csv("Predicted.csv",index=False)
#     df=pd.DataFrame({"CaseId":caseIDs,"Expected":expected_NPS,
#                      "Predicted":predicted_NPS,"confidence":predicted_conf})
#     df.to_csv("Performance 4.0.csv",index=False)
